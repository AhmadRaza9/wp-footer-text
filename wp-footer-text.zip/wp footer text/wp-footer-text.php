<?php
/*
Plugin Name: WP Footer Text
Plugin URI: https://github.com/AhmadRaza9/wp-footer-text.git
Description: Update WordPress Footer Text.
Version: 1.0.0
Contributors: ahmadraza420
Author: Ahmad Raza
Author URI: https://ahmadraza.ga
License: GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: wpplugin
Domain Path:  /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

function wpplugin_custom_admin_footer($footer)
{

    $new_footer = str_replace('.</span>', __(' and <a href="https://ahmadraza.ga">Ahmad Raza</a>.</span>', 'wpplugin'), $footer);
    return $new_footer;

}
add_filter('admin_footer_text', 'wpplugin_custom_admin_footer', 10, 1);
